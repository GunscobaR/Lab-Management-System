<?php
$con = mysqli_connect("localhost","root","","lab_db") or die(mysql_error());

?>