
<style>
	nav#sidebar {
    background: url(../assets/img/<?php echo $_SESSION['setting_cover_img'] ?>);
    background-repeat: no-repeat;
    background-size: cover;
</style>
<nav id="sidebar" class='mx-lt-5' >
		
		<div class="sidebar-list">

				<a href="index.php?page=home" class="nav-item nav-home"><span class='icon-field'><i class="fa fa-home"></i></span> Home</a>
				
				<?php if($_SESSION['login_type'] == 1): ?>	
			    <a href="index.php?page=booked" class="nav-item nav-booked"><span class='icon-field'><i class="fa fa-list"></i></span> Booking List </a>
				<a href="index.php?page=rooms" class="nav-item nav-rooms"><span class='icon-field'><i class="fa fa-desktop"></i></span> Lab </a>
				<a href="index.php?page=users" class="nav-item nav-users"><span class='icon-field'><i class="fa fa-users"></i></span> Users</a>
				<a href="index.php?page=check_out" class="nav-item nav-check_out"><span class='icon-field'><i class="fa fa-file"></i></span> Report </a>
				<?php elseif($_SESSION['login_type'] == 2): ?>
					<a href="index.php?page=check_in" class="nav-item nav-check_in"><span class='icon-field'><i class="fa fa-question-circle"></i></span> Lab Status </a>
					<a href="index.php?page=booked_user" class="nav-item nav-booked"><span class='icon-field'><i class="fa fa-list"></i></span> Booking List </a>
					<a href="../index.php?page=list" class="nav-item nav-booked"><span class='icon-field'><i class="fa fa-book"></i></span> Booking Lab </a>
					<a href="index.php?page=check_out" class="nav-item nav-check_out"><span class='icon-field'><i class="fa fa-file"></i></span> Report </a>
			<?php endif; ?>
		</div>

</nav>
<script>
	$('.nav-<?php echo isset($_GET['page']) ? $_GET['page'] : '' ?>').addClass('active')
</script>